import { v4 } from 'uuid'
import { combineReducers } from 'redux'

const todos = (state = [], action) => {
  switch (action.type) {
    case 'ADD_TODO':
      return [
        ...state,
        {
          id: v4(),
          name: action.name,
          done: false
        }
      ]
    case 'CHANGE_TODO':
      return state.map(item => {
        if (item.id !== action.id) {
          return item
        }

        return {
          ...item,
          done: !item.done
        }
      })
    default:
      return state
  }
}

export default combineReducers({
  todos
})
