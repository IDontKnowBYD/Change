// import {v4} from 'uuid'

export const addTodo = name => ({
  type: 'ADD_TODO',
  name
})

export const changeTodo = id => ({
  type: 'CHANGE_TODO',
  id
})

export const setVisibilityFilter = filter => ({
  type: 'SET_VISIBILITY_FILTER',
  filter
})
