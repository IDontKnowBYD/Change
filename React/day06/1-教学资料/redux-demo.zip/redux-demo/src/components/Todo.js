import React from 'react'

const Todo = ({ active, children, onChangeTodo }) => {
  return (
    <li
      style={{
        textDecoration: active ? 'line-through' : 'none'
      }}
      onClick={onChangeTodo}
    >
      {children}
    </li>
  )
}

export default Todo
