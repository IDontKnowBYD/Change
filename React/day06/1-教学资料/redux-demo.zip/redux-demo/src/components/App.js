import React from 'react'

// 导入AddTodo
import AddTodo from '../containers/AddTodo'
// 导入TodoList
import TodoList from '../containers/TodoList'
import Footer from './Footer'

export default () => {
  return (
    <div>
      <AddTodo />
      <TodoList />
      <Footer />
    </div>
  )
}
