import React from 'react'

export const AddTodo = ({ onAddTodo }) => {
  let todoInput = React.createRef()

  return (
    <div>
      <input type="text" ref={todoInput} />
      <button
        onClick={() => {
          onAddTodo(todoInput.current.value)
          todoInput.current.value = ''
        }}
      >
        添加
      </button>
    </div>
  )
}
