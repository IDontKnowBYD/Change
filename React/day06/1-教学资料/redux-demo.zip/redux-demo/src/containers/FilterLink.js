import React from 'react'

import { NavLink } from 'react-router-dom'
import '../css/filterlink.css'

const FilterLink = ({ filter, children }) => (
  <NavLink
    activeClassName="todos-link-active"
    exact={filter === '/all' ? true : false}
    to={filter === '/all' ? '/' : filter}
  >
    {children}
  </NavLink>
)

export default FilterLink
