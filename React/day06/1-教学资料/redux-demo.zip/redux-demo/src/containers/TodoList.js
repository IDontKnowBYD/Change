import React from 'react'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import { changeTodo } from '../actions'
import Todo from '../components/Todo'

const TodoList = ({ todos, onChangeTodo }) => {
  return (
    <ul>
      {todos.map(item => (
        <Todo
          key={item.id}
          active={item.done}
          onChangeTodo={() => onChangeTodo(item.id)}
        >
          {item.name}
        </Todo>
      ))}
    </ul>
  )
}

const getTodosByFilter = (todos, filter) => {
  if (filter === 'all') {
    return [...todos]
  } else if (filter === 'active') {
    return todos.filter(item => !item.done)
  } else if (filter === 'completed') {
    return todos.filter(item => item.done)
  }

  return [...todos]
}

// 只要state发生改变，mapStateToProps都会重新执行一次
// 以此，来将最新的state映射到组件中
const mapStateToProps = (state, ownProps) => {
  return {
    todos: getTodosByFilter(state.todos, ownProps.match.params.filter)
  }
}

const mapDispatchToProps = (dispatch, props) => ({
  onChangeTodo(id) {
    dispatch(changeTodo(id))
  }
})

export default withRouter(
  connect(
    mapStateToProps,
    mapDispatchToProps
  )(TodoList)
)
