import { connect } from 'react-redux'
import { addTodo } from '../actions'
import { AddTodo } from '../components/AddTodo'

const mapStateToProps = (state, props) => ({})
const mapDispatchToProps = (dispatch, props) => ({
  onAddTodo(todoName) {
    dispatch(addTodo(todoName))
  }
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(AddTodo)
