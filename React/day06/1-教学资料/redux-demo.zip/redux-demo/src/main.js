import React from 'react'
import ReactDOM from 'react-dom'

import { createStore } from 'redux'
import { Provider } from 'react-redux'

import { HashRouter as Router, Route } from 'react-router-dom'

import todos from './reducers'
import App from './components/App'

const store = createStore(todos)

store.subscribe(() => console.log('state =>', store.getState()))

ReactDOM.render(
  <Provider store={store}>
    <Router>
      <Route path="/:filter?" component={App} />
    </Router>
  </Provider>,
  document.getElementById('app')
)
