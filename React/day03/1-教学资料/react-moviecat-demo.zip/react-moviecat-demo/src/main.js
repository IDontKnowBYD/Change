import React from 'react'
import { render } from 'react-dom'

// 导入 App组件，并渲染
import App from './components/App'

render(
  <App></App>,
  document.getElementById('app')
)
