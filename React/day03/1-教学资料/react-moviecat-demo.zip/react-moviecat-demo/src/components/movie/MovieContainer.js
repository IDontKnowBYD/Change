import React from 'react'

import { Layout, Menu } from 'antd'
const { Content, Sider } = Layout

// 导入路由：
import {
  Route, Link,
  Switch    // 包裹的 Route组件 中只有第一匹配的组件会渲染，并且匹配到一个后，后续的Route就不会再次被匹配了
} from 'react-router-dom'

// 导入电影列表组件
import MovieList from './MovieList'
// 导入电影详情组件
import MovieDetail from './MovieDetail'

export default class MovieContainer extends React.Component {
  render () {
    return (
      <Layout style={ { paddingTop: 30, backgroundColor: '#fff' } }>
        <Sider width={200} style={{ background: '#fff', borderRight: '1px solid #ccc' }}>
          <Menu
            mode="inline"
            defaultSelectedKeys={['1']}
            defaultOpenKeys={['sub1']}
            style={{ height: '100%', borderRight: 0 }}
          >
            <Menu.Item key="1"><Link to="/movielist/in_theaters">正在热映</Link></Menu.Item>
            <Menu.Item key="2"><Link to="/movielist/coming_soon">即将上映</Link></Menu.Item>
            <Menu.Item key="3"><Link to="/movielist/top250">top250</Link></Menu.Item>
          </Menu>
        </Sider>
        <Layout style={{ backgroundColor: '#fff' }}>
          <Content style={{ background: '#fff', paddingLeft: 24, margin: 0, minHeight: 280 }}>
            {/* 
              哈希值为：  /movielist/detail/26430636
              
              这个哈希值能够被 电影列表 和 电影详情 的路由规则同时匹配，但是我们只希望
              电影详情来匹配这个哈希值，有两种解决方式：
              1 修改电影详情的路由规则（比如：多添加一个 /m）
                /movielist/detail/m/26430636
                <Route path="/movielist/detail/m/:id" component={MovieDetail}></Route>

              2 Switch组件 - 推荐
                配置路由的规则：匹配范围小的路由规则往前放，匹配范围大的路由规则往后放
            */}
            <Switch>
              {/* 电影详情组件 */}
              <Route path="/movielist/detail/:id" component={MovieDetail}></Route>
              {/* 电影列表组件 */}
              <Route path="/movielist/:movieType/:page?" component={MovieList}></Route>
            </Switch>
        </Content>
        </Layout>
      </Layout>
    )
  }
}
