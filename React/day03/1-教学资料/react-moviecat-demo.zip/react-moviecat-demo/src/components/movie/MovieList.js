import React from 'react'
import { Card, Layout, Rate, Spin, Alert, Pagination } from 'antd'

export default class MovieList extends React.Component {
  constructor (props) {
    super(props)

    // state中应该只存放跟渲染页面相关的内容
    // state中的数据应该尽量少，与更新页面无关的数据，不要添加到 state 中
    this.state = {
      // 电影列表数据
      movieData: {},
      // 是否加载中
      isLoading: true
    }

    // 将各个方法中共用的一些数据，添加给this，而不是添加给 this.state

    // 因为 page 在很多个方法中都用到了，所以，为了方便的获取 page
    // 我们把 page 放在一个公共的地方，这地方就是 this，那么，其他任何方法中
    // 都可以通过 this 来获取到 page
    const { page, movieType } = this.props.match.params
    this.curPage = page || 1
    this.movieType = movieType

    this.isFetching = false
  }

  // 从详情返回该页面的时候，会调用这个钩子函数
  componentDidMount () {
    console.log('componentDidMount')

    this.fetchData()
    this.isFetching = true
  }

  // 该钩子函数会在组件接受到新属性的时候触发：
  componentWillReceiveProps (curProps) {
    // 切换菜单，只要在这个钩子函数中发送请求，获取数据即可
    console.log('componentWillReceiveProps')
    const { page, movieType } = curProps.match.params
    // 每次切换分页，应该重新获取最新的页码
    this.curPage = page || 1
    this.movieType = movieType

    // 每次切换页码, 开启loading 效果
    this.setState({
      isLoading: true
    })

    this.fetchData()
  }

  // 发送请求
  fetchData () {
    if (this.isFetching) {
      return
    }

    const start = (this.curPage - 1) * 6
    fetch(`/api/movie/${this.movieType}?start=${start}&count=6`)
      .then(res => res.json())
      .then(data => {
        // console.log('数据', data)

        this.setState({
          movieData: data,
          isLoading: false
        })

        this.isFetching = false
      })
  }

  render () {
    // 我们应该添加一个加载中的提示
    // 1 如果 isLoading为true，表示数据加载中，应该提示：数据加载中，请稍候
    // 2 如果 isLoading为false，表示数据加载完成，应该渲染电影列表数据
    if (this.state.isLoading) {
      return (
        <Spin tip="Loading...">
          <Alert
            message="友情提示"
            description="电影列表数据正在疯狂加载中，请稍候..."
            type="info"
          />
        </Spin>
      )
    }

    return (
      <Layout>
        {/* 列表结构 */}
        <Layout style={{ display: 'flex', flexDirection: 'row', flexWrap: 'wrap' }}>
          {
            this.state.movieData.subjects.map(movie => {
              return (
                <Card
                  hoverable
                  style={{ width: 190, textAlign: 'center', padding: '20px 0', marginRight: 30 }}
                  key={movie.id}
                  cover={<img alt="example" src={movie.images.small} style={{ width: 100, height: 140, margin: '0 auto' }} />}
                  // 通过箭头函数包裹事件，来给事件处理程序传递参数，顺便解决了 this 指向问题
                  onClick={() => this.goDetail(movie.id)}
                >
                  <h3>{movie.title}</h3>
                  <p>电影类型：{movie.genres.join(',')}</p>
                  <p>上映年份：{movie.year}</p>
                  <Rate disabled defaultValue={ movie.rating.average / 2 } />
                </Card>
              )
            })
          }
        </Layout>

        {/* 分页结构 */}
        <Pagination 
          style={{ marginTop: 30 }} 
          defaultCurrent={1} 
          current={this.curPage - 0}
          total={this.state.movieData.total}
          onChange={(page, pageSize) => this.changePage(page, pageSize)} 
          defaultPageSize={6} />
      </Layout>
    )

  }

  // 分页按钮事件：
  changePage (page, pageSize) {
    // page 就是当前的页码
    // console.log('当前页：', page);

    // 修改路由参数的值：
    this.props.history.push(`/movielist/${this.movieType}/${page}`)
  }

  // 跳转到详情：
  goDetail (id) {
    // 注意：子路由中应该包含 /movielist，否则，内容是不会展示出来的
    // this.props.history.push(`/movielist/detail/m/${id}`)
    this.props.history.push(`/movielist/detail/${id}`)
  }

}