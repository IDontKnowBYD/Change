import React from 'react'

// 导入 antd 布局组件：
import { Layout, Menu } from 'antd'
const { Header, Content, Footer } = Layout

// 导入自定义样式
import '../css/index.css'

// 导入路由：
import {
  HashRouter as Router,
  Link,
  Route
} from 'react-router-dom'

// 导入自定义组件：
import Home from './Home'
import About from './About'
import Movie from './movie/MovieContainer'

// 使用路由的步骤：
// 1 使用 Router 包裹整个应用
// 2 使用 Link 包裹路由入口（导航菜单）
// 3 使用 Route 指定路由出口( 路由展示在页面中的哪个位置 )

// react 路由匹配的特点：
// 只要切换路由，所有的 Route组件 都会被全部匹配一次
// 只要这个Route组件的 path（路由规则） 能够匹配当前哈希值，那么，这个Route就会展示
// 比如：
//  1 当前的哈希值为 /movielist （URL）
//  2 那么，我们配置的三个Route组件，就会全部匹配一次
//  3 首先 <Route path="/" component={Home}></Route> 中path能够匹配 /movielist 所以，展示该组件
//  4 同样的 <Route path="/movielist" component={Movie}></Route> 中的paht能够匹配 /moveilist ，所以，展示该组件
//  匹配规则：只要 path 包含在 哈希值中，就表示匹配成功（模糊匹配）
// 总结：1 所有Route都会进行匹配 2 匹配规则为：模糊匹配

export default class App extends React.Component {
  render () {
    return (
      <Router>
        <Layout className="layout">
          <Header>
            <div className="logo" />
            <Menu
              theme="dark"
              mode="horizontal"
              defaultSelectedKeys={['1']}   // 设置默认选中哪个菜单
              style={{ lineHeight: '64px' }}
            >

            {/* to 用来指定路由的哈希值 */}
              <Menu.Item key="1"><Link to="/">首页</Link></Menu.Item>
              <Menu.Item key="2"><Link to="/movielist/in_theaters">电影列表</Link></Menu.Item>
              <Menu.Item key="3"><Link to="/about">关于</Link></Menu.Item>
            </Menu>
          </Header>
          <Content>
            <div style={{ background: '#fff', minHeight: 280 }}>
            {/* path 表示路由规则 */}
            {/* exact 表示完全匹配，也就是：当 哈希值 与 path 完全相同，才会被匹配 */}
              <Route exact path="/" component={Home}></Route>
              <Route path="/movielist" component={Movie}></Route>
              <Route path="/about" component={About}></Route>
            </div>
          </Content>
          <Footer style={{ textAlign: 'center' }}>
              Ant Design ©2016 Created by Ant UED
          </Footer>
        </Layout>
      </Router>
    )
  }
}