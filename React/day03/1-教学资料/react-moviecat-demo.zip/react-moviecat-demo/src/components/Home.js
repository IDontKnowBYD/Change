import React from 'react'

export default () => (
  <div>
    <h1>这是电影的首页, 电影很棒, react更棒！</h1>
  </div>
)