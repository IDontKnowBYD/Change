import React from 'react'

export default () => (
  <div>
    <h1>关于电影的一切，尽在 react 电影！</h1>
  </div>
)