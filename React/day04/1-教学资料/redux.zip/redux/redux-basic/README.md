# redux

- 状态管理工具，用来管理应用中的数据

## 核心

- Action：行为的抽象，视图中的每个用户交互都是一个action
  - 比如：点击按钮
- Reducer：行为响应的抽象，也就是：根据action行为，执行相应的逻辑操作，更新state
  - 比如：点击按钮后，添加任务，那么，添加任务这个逻辑放到 Reducer 中
  - 1 创建State
- Store：
  - 1 **Redux应用只能有一个store**
  - 2 `getState()`：获取state
  - 3 `dispatch(action)`：更新state

```js
/* action */

// 在 redux 中，action 就是一个对象
// action 必须提供一个：type属性，表示当前动作的标识
// 其他的参数：表示这个动作需要用到的一些数据
{ type: 'ADD_TODO', name: '要添加的任务名称' }

// 这个动作表示要切换任务状态
{ type: 'TOGGLE_TODO', id: 1 }
```

```js
/* reducer */

// 第一个参数：表示状态（数据），我们需要给初始状态设置默认值
// 第二个参数：表示 action 行为
function todo(state = [], action) {
  switch(action.type) {
    case 'ADD_TODO':
      state.push({ id: Math.random(), name: action.name, completed: false })
      return state
    case 'TOGGLE_TODO':
      for(var i = 0; i < state.length; i++) {
        if (state[i].id === action.id) {
          state[i].completed = !state[i].completed
          break
        }
      }
      return state
    default:
      return state
  }
}

// 要执行 ADD_TODO 这个动作：
dispatch( { type: 'ADD_TODO', name: '要添加的任务名称' } )

// 内部会调用 reducer
todo(undefined, { type: 'ADD_TODO', name: '要添加的任务名称' })
```