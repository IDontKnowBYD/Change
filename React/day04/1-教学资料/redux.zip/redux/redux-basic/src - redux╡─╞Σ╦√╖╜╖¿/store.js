import { createStore } from 'redux'
import counter from './reducers'
import * as TodoActionCreators from './actions'

const store = createStore(counter)

store.subscribe(() => {
  console.log(store.getState())
})

// 将action和dispatch绑定到一起，返回可以直接更新state的action方法
// 将 actions 和 dispatch 揉在一起，成为具备操作 store.state 的 actions
import { bindActionCreators } from 'redux'

// 将 dispatch 与 action 绑定到一起，并且返回 能够更新state的action函数 对象集合
// 直接调用返回对象中的 action creator 方法，就可以更改状态了
const boundActionCreators = bindActionCreators(TodoActionCreators, store.dispatch)
console.log(boundActionCreators)

// 调用 action creator 方法，修改状态
boundActionCreators.increment(6)
boundActionCreators.increment(6)

// --------------------------

function compose(...funcs) {
  if (funcs.length === 0) {
    return (arg) => arg
  }
  if (funcs.length === 1) {
    return funcs[0]
  }
  return funcs.reduce((a, b) => (
      (...args) => a(b(...args))
    )
  )
}

const f1 = () => console.log(1)
const f2 = () => console.log(1)

console.log( compose() );
console.log( compose(f1) );
console.log( compose(f1, f2)() );