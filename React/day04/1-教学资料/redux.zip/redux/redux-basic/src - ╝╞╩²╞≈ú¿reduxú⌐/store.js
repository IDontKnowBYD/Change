import { createStore } from 'redux'
import counter from './reducers'
import { increment, decrement } from './actions'

// const createStore = (reducer) => {
//   let state
//   let listeners = []

//   state = reducer(state, {})
  
//   // 用来返回当前的state
//   const getState = () => state
//   // 根据action调用reducer返回新的state并触发listener
//   const dispatch = (action) => {
//     state = reducer(state, action)
//     listeners.forEach(listener => listener())
//   }
//   /* 这里的subscribe有两个功能
//    * 调用 subscribe(listener) 会使用listeners.push(listener)注册一个listener
//    * 而调用 subscribe 的返回函数则会注销掉listener
//    */
//   const subscribe = (listener) => {
//     listeners.push(listener)
//     return () => {
//       listeners = listeners.filter(l => l !== listener)
//     }
//   }

//   return { getState, dispatch, subscribe }
// }

const store = createStore(counter)

console.log(store)
console.log(store.getState())

const unsubscribe = store.subscribe(() => {
  console.log(store.getState())
})

store.dispatch( increment(1) )

/* // 创建store
const store = createStore(counter)

// 获取状态
console.log(store.getState())

const unsubscribe = store.subscribe(() => {
  console.log(store.getState())
})

store.dispatch( increment(1) )
store.dispatch( increment(1) )
store.dispatch( decrement(1) )

unsubscribe() */
