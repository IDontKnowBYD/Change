/* 
  三个动作
  1 添加任务
  2 切换任务状态
  3 显示不同状态的任务
*/
let nextTodoId = 0

// 添加任务
export const addTodo = (text) => ({
  type: 'ADD_TODO',
  id: nextTodoId++,
  text
})

// 切换任务
export const toggleTodo = (id) => ({
  type: 'TOGGLE_TODO',
  id
})

// 显示不同状态的任务
export const setVisibilityFilter = (filter) => ({
  type: 'SET_VISIBILITY_FILTER',
  filter
})

// 三种不同任务状态
export const VisibilityFilters = {
  SHOW_ALL: 'SHOW_ALL',
  SHOW_COMPLETED: 'SHOW_COMPLETED',
  SHOW_ACTIVE: 'SHOW_ACTIVE'
}