import React from 'react'
import ReactDOM from 'react-dom'
import { Provider, connect } from 'react-redux'

import { createStore } from 'redux'
import counter from './reducers'
import { increment, decrement } from './actions'

// 创建store
const store = createStore(counter)

store.subscribe(() => console.log(store.getState()))

// 创建Counter组件
const Counter = ({ count, onIncrement, onDecrement }) => {
  return (
    <div>
      <p>{count}</p>
      <button onClick={onIncrement}>+</button>
      <button onClick={onDecrement}>-</button>
    </div>
  )
}

// 将redux管理的状态，映射到 props 中
const mapStateToProps = state => {
  return {
    count: state
  }
}

// 将修改redux数据的方法，映射到 props 中
const mapDispatchToProps = dispatch => {
  return {
    onIncrement: () => {
      dispatch(increment(1))
    },
    onDecrement: () => {
      dispatch(decrement(1))
    }
  }
}

const CounterContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)(Counter)

// Provider：传递store的一个容器组件，一般把它套在应用组件的最外层
ReactDOM.render(
  <Provider store={store}>
    <CounterContainer />
  </Provider>,
  document.getElementById('app')
)
