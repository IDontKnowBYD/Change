import React from 'react'
import ReactDOM from 'react-dom'

import { createStore } from 'redux'
import counter from './reducers'
import { increment, decrement } from './actions'

// 创建store
const store = createStore(counter)

// 创建Counter组件
const Counter = ({ value, onIncrement, onDecrement }) => {
  return (
    <div>
      <p>{ value }</p>
      <button onClick={ onIncrement }>+</button>
      <button onClick={ onDecrement }>-</button>
    </div>
  )
}

const render = () => {
  ReactDOM.render(
    <Counter
      value={store.getState()}
      onIncrement={() => store.dispatch( increment(1) ) }
      onDecrement={() => store.dispatch( decrement(1) ) }
      />,
    document.getElementById('app')
  )
}

// 订阅状态改变事件，当通过dispatch修改state的时候，订阅事件（回调函数）就会触发
store.subscribe(() => {
  console.log(store.getState())
})
store.subscribe(render)
render()
