import React from 'react'
import ReactDOM from 'react-dom'

import { createStore } from 'redux'
import counter from './reducers'
import { increment, decrement } from './actions'

// 创建store
const store = createStore(counter)

// 创建Counter组件
const Counter = ({ value, onIncrement, onDecrement }) => {
  return (
    <div>
      <p>{ value }</p>
      <button onClick={ onIncrement }>+</button>
      <button onClick={ onDecrement }>-</button>
    </div>
  )
}

class CounterContainer extends React.Component {
  componentDidMount() {
    this.unsubscribe = store.subscribe(() => {
      // 强制更新
      this.forceUpdate()
    })
  }

  componentWillUnmount() {
    this.unsubscribe()
  }

  render() {
    return (
      <Counter
        value={store.getState()}
        onIncrement={() => store.dispatch(increment(1))}
        onDecrement={() => store.dispatch(decrement(1))}
      />
    )
  }
}


store.subscribe(() => { console.log(store.getState()) })

ReactDOM.render(
  <CounterContainer />,
  document.getElementById('app')
)
