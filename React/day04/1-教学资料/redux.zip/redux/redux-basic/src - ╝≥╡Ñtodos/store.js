import { createStore } from 'redux'
import todoApp from './reducers.js'

// 根据我们创建好的 reducer，创建 store，store中包含了所有的数据，以及操作数据的方法
let store = createStore(todoApp)



// 测试
import { addTodo, toggleTodo, setVisibilityFilter } from './actions'

// 打印初始状态
// console.log('初始化：', store.getState())

// 每次 state 更新时，打印日志
// 注意 subscribe() 返回一个函数用来注销监听器
// subscribe 用来监听 state 数据的变化， 只有state 发生改变，那么 subscribe 就会监视到
let unsubscribe = store.subscribe(() =>
  console.log(store.getState())
)

// 发起一系列 action
// store.dispatch( { type: 'ADD_TODO', text: 'A要吃米饭' } )
store.dispatch( addTodo('A要吃米饭') )
// store.dispatch( addTodo('Learn about reducers'))
// store.dispatch( addTodo('Learn about store'))

// store.dispatch( toggleTodo(0))
// store.dispatch( toggleTodo(1))

// store.dispatch( setVisibilityFilter('SHOW_COMPLETED'))

// 停止监听 state 更新
unsubscribe();
