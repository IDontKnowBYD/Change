/* 
  action 是行为的抽象，视图中的每个用户交互都是一个action
  1 是一个普通对象
  2 一般由方法生成
  3 必须有一个type
*/

/*
 * action 创建函数
 */
// addTodo('吃饭') => { type: 'ADD_TODO', text: '吃饭' }
// addTodo('睡觉') => { type: 'ADD_TODO', text: '睡觉' }
export function addTodo(text) {
  return { type: 'ADD_TODO', text }
}

export function toggleTodo(index) {
  return { type: 'TOGGLE_TODO', index }
}

export function setVisibilityFilter(filter) {
  return { type: 'SET_VISIBILITY_FILTER', filter }
}