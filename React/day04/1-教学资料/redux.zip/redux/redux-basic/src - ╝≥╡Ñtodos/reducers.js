/* 
  reducer 是行为响应的抽象，也就是：根据action对象，执行相应的逻辑操作，跟新state
  1 是纯函数（输出由输入决定）
  2 传入旧状态和action
  3 返回新状态
*/

import { combineReducers } from 'redux'

function visibilityFilter(state = 'SHOW_ALL', action) {
  switch (action.type) {
    case 'SET_VISIBILITY_FILTER':
      return action.filter
    default:
      return state
  }
}

// 1 todos(undefined, { type: 'ADD_TODO', text: '吃饭' })
// 2 todos([{}], { type: 'TOGGLE_TODO', index: 0 })
function todos(state = [], action) {
  switch (action.type) {
    case 'ADD_TODO':
      return [
        ...state,
        {
          text: action.text,
          completed: false
        }
      ]
    case 'TOGGLE_TODO':
      return state.map((todo, index) => {
        if (index === action.index) {
          return Object.assign({}, todo, {
            completed: !todo.completed
          })
        }
        return todo
      })
    default:
      return state
  }
}

// 将两个 reducer 合并为一个reducer
// todoApp 中就包含了：上面两个 reducer 中的所有的 switch 情况
const todoApp = combineReducers({
  visibilityFilter,
  todos
})

// console.log('todoApp', todoApp);
export default todoApp